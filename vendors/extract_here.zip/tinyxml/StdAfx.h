#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
// C RunTime Header Files
#include <stdlib.h>
// #include <malloc.h> // VC++ 7.1 Compile Errors.
#include <memory.h>
#include <tchar.h>